import 'dart:io';

void checkDayType(String day) {
  // Convert the input to lowercase for case-insensitive comparison
  String lowerDay = day.toLowerCase();

  // Check if the day is a weekday or weekend
  if (lowerDay == 'saturday' || lowerDay == 'sunday') {
    print("$day is a weekend.");
  } else if (lowerDay == 'monday' || lowerDay == 'tuesday' || 
             lowerDay == 'wednesday' || lowerDay == 'thursday' || 
             lowerDay == 'friday') {
    print("$day is a weekday.");
  } else {
    print("Invalid day: $day");
  }
}

void main() {
 stdout.write("Enter a day : ");
 String day=stdin.readLineSync()!;
 checkDayType(day);
}
