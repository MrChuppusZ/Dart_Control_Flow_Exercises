import 'dart:io';
void main()
{
  int sum = 0;
  while (true) {
    stdout.write("Enter a number (or a negative number to stop): ");
    int number = int.parse(stdin.readLineSync()!);
    if (number < 0) {
      break;
    }
    sum += number;
  }
  print("Sum of positive numbers: $sum");
}